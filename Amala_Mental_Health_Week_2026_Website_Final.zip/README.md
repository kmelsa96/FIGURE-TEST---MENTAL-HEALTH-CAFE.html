# Amala Mental Health Week 2026
Self-contained responsive website for Mental Health Week ’26.
Open `index.html` directly in a browser. All three supplied artwork images are embedded in the HTML, so no external assets are required.
For later GitHub Pages deployment, upload `index.html` to a repository and enable GitHub Pages.
